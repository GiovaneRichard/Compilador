import java.util.List;

/***
 * Classe principal contendo a funcao main. 
 */
public class MainClass {
    public ID className;
    public ID mainArgName;
    public List<Statement> mainStatementList;
    
}
