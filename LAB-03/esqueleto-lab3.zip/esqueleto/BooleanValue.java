public class BooleanValue {
    public String value;
}
