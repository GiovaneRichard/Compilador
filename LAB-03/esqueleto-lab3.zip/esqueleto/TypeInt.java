public class TypeInt extends Type {

}

