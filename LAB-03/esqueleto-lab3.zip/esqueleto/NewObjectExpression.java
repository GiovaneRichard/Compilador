public class NewObjectExpression extends Expression {
    public ID objectName;
}
