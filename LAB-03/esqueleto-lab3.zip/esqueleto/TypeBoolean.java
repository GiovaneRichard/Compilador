public class TypeBoolean extends Type {

}

