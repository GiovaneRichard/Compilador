public class AttributionStatement extends Statement {
    public ID leftSide;
    public Expression rightSide;
    
}

