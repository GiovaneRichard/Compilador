/***
 * Um comando.
 */
public class Statement {

}

