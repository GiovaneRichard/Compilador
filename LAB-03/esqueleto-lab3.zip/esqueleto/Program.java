import java.util.List;

public class Program {
    public MainClass mainClass;
    public List<ClassDeclaration> classDeclarationList;
    
}
