public class TypeID extends Type {
    public ID typeName;
}

