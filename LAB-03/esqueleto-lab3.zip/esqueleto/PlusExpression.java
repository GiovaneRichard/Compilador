public class PlusExpression extends Expression {
    public Expression left;
    public Expression right;
}
