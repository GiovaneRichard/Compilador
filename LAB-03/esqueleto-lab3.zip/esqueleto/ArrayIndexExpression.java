public class ArrayIndexExpression extends Expression {
    public Expression array;
    public Expression index;
}
