public class Token {
    TokenType type;
    String image;
}
