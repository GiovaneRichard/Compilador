public class NumberDecimalExpression extends Expression {
    public NumberDecimal value;
}
