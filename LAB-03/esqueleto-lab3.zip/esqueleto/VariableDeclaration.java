/***
 * Declaracao de uma variavel.
 */
public class VariableDeclaration {
    public Type variableType;
    public ID variableName;
    
}
