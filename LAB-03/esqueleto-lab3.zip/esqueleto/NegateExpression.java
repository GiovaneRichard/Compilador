public class NegateExpression extends Expression {
    public Expression exp;
}
