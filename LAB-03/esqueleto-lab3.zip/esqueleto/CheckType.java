public class CheckType {
    public boolean correctTypes(FunctionDeclaration fun) {
	
    }
}
