public class TypeIntVector extends Type {

}
