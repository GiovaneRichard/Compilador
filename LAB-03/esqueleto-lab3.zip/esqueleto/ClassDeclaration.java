import java.util.List;
/***
 * Declaracao de uma classe.
 */
public class ClassDeclaration {
    public ID className;
    public List<VariableDeclaration> variableDeclarationList;
    public List<FunctionDeclaration> functionDeclarationList;
    
}
