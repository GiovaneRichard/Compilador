public class ArrayLengthExpression extends Expression {
    public Expression array;
}
