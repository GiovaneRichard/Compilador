public class BooleanValueExpression extends Expression {
    public BooleanValue value;
}
