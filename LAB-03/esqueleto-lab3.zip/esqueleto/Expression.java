/***
 * Uma expressao.
 */
public class Expression {

}

