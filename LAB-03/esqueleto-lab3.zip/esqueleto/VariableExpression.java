public class VariableExpression extends Expression {
    public ID varName;
}
