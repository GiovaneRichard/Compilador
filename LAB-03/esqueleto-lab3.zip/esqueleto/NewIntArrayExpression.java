public class NewIntArrayExpression extends Expression {
    public Expression arraySize;
}
