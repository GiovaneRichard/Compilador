import java.util.List;

public class ParserLR {
    public ParserLR() {
	
    }

    public Program parse(List<Token> entrada) {

	return ;
    }
}
