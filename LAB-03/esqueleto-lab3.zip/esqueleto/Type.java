/***
 * Tipo de Dado.
 */
public class Type {
    
}
