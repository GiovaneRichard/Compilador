public class ArrayAttributionStatement extends Statement {
    public ID arrayName;
    public ID arrayIndex;
    public Expression rightSide;
    
}

