public class NumberDecimal {
    public String numberImage;
}
