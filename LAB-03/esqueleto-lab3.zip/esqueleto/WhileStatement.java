public class WhileStatement extends Statement {
    public Expression condition;
    public Statement body;

}

