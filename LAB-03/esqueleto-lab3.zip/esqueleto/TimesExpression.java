public class TimesExpression extends Expression {
    public Expression left;
    public Expression right;
}
